import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { initDatabase } from './backend/config/db';
import apiRouter from './backend/routes/apiRouter';

dotenv.config();

async function startServer() {
  await initDatabase();

  const app = express();
  const PORT = Number(process.env.PORT || 3000);
  const publicPath = path.join(process.cwd(), 'public');

  app.use(express.json({ limit: '4mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Serve uploaded photos, legacy seeded image paths, and pure HTML/CSS/JS frontend
  app.use('/uploads', express.static(path.join(publicPath, 'uploads')));
  app.use('/src/assets/images', express.static(path.join(publicPath, 'images')));
  app.use(express.static(publicPath, { extensions: ['html'] }));

  // RESTful API endpoints
  app.use('/api', apiRouter);

  // API 404 handler
  app.use('/api', (_req: express.Request, res: express.Response) => {
    res.status(404).json({ error: 'API route not found' });
  });

  // API error handler
  app.use('/api', (err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    res.status(400).json({ error: err.message || 'Request error' });
  });

  // Fallback to pure HTML5 entry point
  app.get('*', (_req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FurEver server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
