import { Request, Response, NextFunction } from 'express';
import { FurEverModel } from '../models/fureverModel';

/**
 * Simple User Context attached to each Express request.
 * No JWT tokens are used — we look up the user directly from the SQL `users` table
 * using the `x-user-id` header (or default to the demo guest adopter account).
 */
export interface RequestUser {
  userId: string;
  email: string;
  role: 'adopter' | 'lister' | 'admin';
  fullName: string;
}

export interface AuthenticatedRequest extends Request {
  user?: RequestUser;
}

const DEFAULT_GUEST_USER_ID = 'user-adopter-1';

async function resolveUserFromRequest(req: Request): Promise<RequestUser | undefined> {
  const headerUserId = req.headers['x-user-id'];
  const requestedId = typeof headerUserId === 'string' && headerUserId.trim()
    ? headerUserId.trim()
    : DEFAULT_GUEST_USER_ID;

  const user =
    (await FurEverModel.findUserById(requestedId)) ||
    (await FurEverModel.findUserById(DEFAULT_GUEST_USER_ID));

  if (!user) return undefined;

  return {
    userId: user.id,
    email: user.email,
    role: user.role,
    fullName: user.full_name,
  };
}

export async function optionalAuth(
  req: AuthenticatedRequest,
  _res: Response,
  next: NextFunction
): Promise<void> {
  try {
    req.user = await resolveUserFromRequest(req);
  } catch {
    req.user = undefined;
  }
  next();
}

export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const resolved = await resolveUserFromRequest(req);
    if (!resolved) {
      res.status(404).json({ error: 'No active user record found in database.' });
      return;
    }
    req.user = resolved;
    next();
  } catch (err) {
    res.status(500).json({ error: 'Failed to load user context: ' + (err as Error).message });
  }
}

export function requireRole(...roles: Array<'adopter' | 'lister' | 'admin'>) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Please select or log in to an account first.' });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: 'You do not have permission to perform this action.' });
      return;
    }
    next();
  };
}
