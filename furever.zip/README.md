# FurEver — Pet Adoption & Matching Platform

## 1. Project Overview
**FurEver** is a full-stack web application built to simplify ethical pet adoption in **Pune, Maharashtra**. It connects prospective pet adopters, local animal shelters/foster caregivers, and verified veterinary clinics on one simple platform.

Users can browse and filter pets by Pune neighbourhood, discover pets one-by-one in Swipe Match, take a 6-step lifestyle Match Quiz, submit adoption applications with automated eligibility feedback, find 24/7 veterinary clinics, and track application statuses in real time.

---

## 2. Technology Stack
| Layer | Technologies Used |
| --- | --- |
| **Frontend** | Pure **HTML5**, **CSS3**, and **Vanilla JavaScript** (no React, Tailwind, or Vite) |
| **Backend** | **Node.js**, **Express.js** (`express`), **Multer** (`multer` for photo uploads), **TypeScript** (`tsx` / `esbuild`) |
| **Accounts** | Direct Express + SQL `users` lookup (`x-user-id` header, no JWT tokens) & password hashing (`bcryptjs`) |
| **Database** | **MySQL 8+** via `mysql2/promise` (with automatic local JSON fallback in `data/furever-db.json`) |
| **Typography** | Poppins (headings) & Inter (body text) |

---

## 3. Project Folder Structure (Easy Page Access)
```text
├── public/                        # Pure HTML + CSS + Vanilla JS Frontend
│   ├── index.html                 # Home Page
│   ├── browse.html                # Browse Pets Page
│   ├── swipe.html                 # Swipe Match Page
│   ├── quiz.html                  # Match Finder Quiz Page
│   ├── list-pet.html              # List a Pet Page
│   ├── vets.html                  # Veterinary Directory Page
│   ├── status.html                # Adoption Status & Activity Page
│   ├── admin.html                 # Admin Dashboard Page
│   ├── css/
│   │   └── style.css              # Pure CSS3 stylesheet
│   ├── js/
│   │   ├── common.js              # Shared navbar, footer, API client & modals
│   │   └── pages/                 # One dedicated JS file per HTML page
│   │       ├── home.js
│   │       ├── browse.js
│   │       ├── swipe.js
│   │       ├── quiz.js
│   │       ├── list-pet.js
│   │       ├── vets.js
│   │       ├── status.js
│   │       └── admin.js
│   ├── images/                    # Featured pet images
│   ├── pets/                      # Pet photography
│   └── uploads/                   # User-uploaded pet photos
├── backend/                       # Node.js + Express MVC Backend
│   ├── config/
│   │   ├── db.ts                  # MySQL2 connection pool + fallback initializer
│   │   └── localStore.ts          # Local JSON relational fallback
│   ├── controllers/               # Request handlers (auth, pets, quiz, applications, vets, admin)
│   ├── middleware/
│   │   └── auth.ts                # Optional x-user-id SQL user resolver (no JWT)
│   ├── models/
│   │   └── fureverModel.ts        # SQL queries & data access layer
│   └── routes/
│       └── apiRouter.ts           # Express REST API routes & Multer file upload setup
├── database/
│   ├── schema.sql                 # Normalized MySQL schema
│   └── seed.sql                   # Sample Pune users, pets & vet clinics
├── server.ts                      # Express server serving public/ & /api/* on port 3000
├── package.json
└── tsconfig.json
```

---

## 4. API Endpoints Summary (`/api`)

| Method | Endpoint | Access | Description |
| --- | --- | --- | --- |
| `GET` | `/api/health` | Public | Server health, DB engine status, and platform counts |
| `POST` | `/api/auth/register` | Public | Create a new adopter or shelter account in SQL |
| `POST` | `/api/auth/login` | Public | Verify email & password against SQL `users` table (no JWT) |
| `POST` | `/api/auth/logout` | Public | Clear active client account selection |
| `GET` | `/api/auth/me` | Public / Active User | Fetch active user, favourites, and notifications |
| `PUT` | `/api/users/profile` | Public / Active User | Update user profile details |
| `GET` | `/api/pets` | Public | List pets with optional query filters |
| `GET` | `/api/pets/:id` | Public | Fetch full pet details, images, and lister info |
| `POST` | `/api/pets` | Public | Create a new pet listing (with optional `photo` upload) |
| `PATCH` | `/api/pets/:id/status` | Owner / Admin | Update pet status (`AVAILABLE`, `PENDING`, `ADOPTED`) |
| `DELETE` | `/api/pets/:id` | Owner / Admin | Delete a pet listing |
| `GET` | `/api/favorites` | Public | Get active user's saved pet IDs |
| `POST` | `/api/favorites/toggle` | Public | Add or remove a pet from favourites |
| `POST` | `/api/swipes` | Public | Record `like` or `pass` swipe decision |
| `GET` | `/api/swipes/history` | Public | Fetch swipe history |
| `POST` | `/api/quiz/recommend` | Public | Score available pets against 6 lifestyle answers |
| `GET` | `/api/applications` | Public | List applications for active account or guest session |
| `POST` | `/api/applications` | Public | Submit adoption application + run eligibility check |
| `PATCH` | `/api/applications/:id/status` | Applicant / Lister / Admin | Withdraw, approve, reject, or review application |
| `GET` | `/api/vets` | Public | List verified Pune veterinary clinics |
| `POST` | `/api/vets` | Admin | Add a new veterinary clinic |
| `GET` | `/api/admin/dashboard` | Admin | Retrieve aggregate counts and full admin tables |
| `PATCH` | `/api/admin/users/:id` | Admin | Activate/deactivate users or update roles |
| `DELETE` | `/api/admin/vets/:id` | Admin | Remove a veterinary clinic |

---

## 5. Running Locally
```bash
# 1. Install dependencies
npm install

# 2. Start server (Express API + HTML/CSS/JS frontend on port 3000)
npm run dev

# 3. Type-check and build server
npm run lint
npm run build
```
Open **`http://localhost:3000`** in your browser.

---

## 6. Demo Login Credentials
All pre-seeded accounts use the password **`furever123`**:

| Role | Email | Password | Capabilities |
| --- | --- | --- | --- |
| **Adopter** | `adopter@furever.com` | `furever123` | Browse, swipe, save favourites, submit & track applications |
| **Shelter / Lister** | `shelter@furever.com` | `furever123` | List pets, update adoption availability, review incoming applications |
| **Administrator** | `admin@furever.com` | `furever123` | Access Admin Dashboard, manage users, applications, pets & vets |
