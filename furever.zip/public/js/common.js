/*
 * ============================================================================
 * FurEver — Shared Frontend Helpers (public/js/common.js)
 * ============================================================================
 * Loaded on every HTML page before the page-specific script.
 * Handles:
 *   1. Shared state & active user session (localStorage, no JWT)
 *   2. API calls to the Node.js + Express backend (/api/*)
 *   3. Shared UI: Navbar, Footer, Pet Cards, Toast banner
 *   4. Shared Modals: Pet Details, Adoption Application, Account/Login, Saved
 * ============================================================================
 */

window.FurEverApp = (() => {
  const ACTIVE_USER_KEY = 'furever_active_user_id';

  // Central state shared by whichever page is currently open
  const state = {
    currentPage: 'home',
    mobileMenuOpen: false,
    pets: [],
    vets: [],
    user: null,
    favouriteIds: [],
    applications: [],
    swipeHistory: [],
    notifications: [],
    toastTimer: null,
    onDataChanged: null,
  };

  /* --------------------------------------------------------------------------
   * 1. SMALL UTILITY HELPERS
   * -------------------------------------------------------------------------- */

  // Escapes special HTML characters so database text cannot break page HTML
  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function getActiveUserId() {
    return localStorage.getItem(ACTIVE_USER_KEY) || '';
  }

  function setActiveUserId(userId) {
    if (userId) localStorage.setItem(ACTIVE_USER_KEY, userId);
    else localStorage.removeItem(ACTIVE_USER_KEY);
  }

  // Inline SVG icons (no external icon library needed)
  function icon(name, extraClass = '') {
    const cls = extraClass ? ` class="${extraClass}"` : '';
    const icons = {
      paw: `<svg${cls} viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="4" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="20" cy="16" r="2"/><path d="M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z"/></svg>`,
      'heart-filled': `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="#8E6CE0" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
      heart: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
      'heart-nav': `<svg${cls} viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
      'heart-lg': `<svg${cls} viewBox="0 0 24 24" width="24" height="24" fill="#8E6CE0" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
      menu: `<svg${cls} viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>`,
      'map-pin': `<svg${cls} viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>`,
      search: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>`,
      'arrow-right': `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>`,
      'arrow-left': `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>`,
      shield: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>`,
      x: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`,
      'x-lg': `<svg${cls} viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`,
      rotate: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>`,
      check: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,
      'check-circle': `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#8E6CE0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`,
      clock: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
      phone: `<svg${cls} viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
      mail: `<svg${cls} viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>`,
      user: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
      logout: `<svg${cls} viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>`,
    };
    return icons[name] || '';
  }

  // Shows a temporary notification popup in the bottom-right corner
  function showToast(message) {
    const root = document.getElementById('toast-root');
    if (!root) return;
    if (state.toastTimer) window.clearTimeout(state.toastTimer);

    root.innerHTML = `
      <div role="status" class="toast-banner">
        ${icon('check-circle')}
        <span>${escapeHtml(message)}</span>
      </div>
    `;
    state.toastTimer = window.setTimeout(() => {
      root.innerHTML = '';
    }, 3500);
  }

  /* --------------------------------------------------------------------------
   * 2. API REQUESTS (Browser -> Express Server -> SQL Database)
   * -------------------------------------------------------------------------- */

  // Sends a request to /api/* and optionally includes x-user-id (no JWT token)
  async function apiRequest(endpoint, options = {}) {
    const headers = { ...(options.headers || {}) };
    const activeUserId = getActiveUserId();
    if (activeUserId) headers['x-user-id'] = activeUserId;

    // FormData sets its own multipart boundary header automatically
    if (!(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch('/api' + endpoint, { ...options, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `Request failed (${res.status})`);
    }
    return data;
  }

  async function loadPublicData() {
    const [petsRes, vetsRes] = await Promise.all([apiRequest('/pets'), apiRequest('/vets')]);
    state.pets = petsRes.pets || [];
    state.vets = vetsRes.vets || [];
  }

  async function loadUserDashboardData() {
    try {
      const [meRes, appsRes, swipeRes] = await Promise.all([
        apiRequest('/auth/me'),
        apiRequest('/applications'),
        apiRequest('/swipes/history'),
      ]);
      state.user = getActiveUserId() ? meRes.user : null;
      state.favouriteIds = meRes.favouriteIds || [];
      state.notifications = meRes.notifications || [];
      state.applications = appsRes.applications || [];
      state.swipeHistory = swipeRes.history || [];
    } catch (_err) {
      setActiveUserId('');
      state.user = null;
    }
  }

  /* --------------------------------------------------------------------------
   * 3. SHARED UI RENDERERS (Navbar, Footer, Pet Card)
   * -------------------------------------------------------------------------- */

  function renderNavbar() {
    const header = document.getElementById('site-navbar');
    if (!header) return;

    const links = [
      { id: 'home', href: '/index.html', label: 'Home' },
      { id: 'browse', href: '/browse.html', label: 'Browse Pets' },
      { id: 'swipe', href: '/swipe.html', label: 'Swipe Match' },
      { id: 'quiz', href: '/quiz.html', label: 'Match Quiz' },
      { id: 'vets', href: '/vets.html', label: 'Vets' },
      { id: 'status', href: '/status.html', label: 'Status' },
    ];
    if (state.user && state.user.role === 'admin') {
      links.push({ id: 'admin', href: '/admin.html', label: 'Admin' });
    }

    const desktopLinks = links
      .map(
        (item) =>
          `<a href="${item.href}" class="nav-link${state.currentPage === item.id ? ' active' : ''}">${escapeHtml(item.label)}</a>`
      )
      .join('');

    const mobileLinks =
      links
        .map(
          (item) =>
            `<a href="${item.href}" class="mobile-nav-item${state.currentPage === item.id ? ' active' : ''}">${escapeHtml(item.label)}</a>`
        )
        .join('') +
      `<a href="/list-pet.html" class="mobile-nav-item${state.currentPage === 'list-pet' ? ' active' : ''}">List a Pet</a>`;

    const favCount = state.favouriteIds.length;
    const badgeHtml = favCount > 0 ? `<span class="fav-badge">${favCount}</span>` : '';

    const authButton = state.user
      ? `<button type="button" id="auth-btn-desktop" class="btn btn-secondary btn-sm">${icon('user')}<span>${escapeHtml(state.user.full_name.split(' ')[0])}</span></button>`
      : `<button type="button" id="auth-btn-desktop" class="btn btn-primary btn-sm">Login / Register</button>`;

    const authMobileText = state.user
      ? `Account: ${state.user.full_name} (Switch / Create)`
      : 'Create Account / Login';

    header.innerHTML = `
      <div class="container navbar-inner">
        <a href="/index.html" class="brand-btn">
          <span class="brand-icon" aria-hidden="true">${icon('paw')}</span>
          <span class="brand-name">FurEver</span>
        </a>

        <div class="desktop-nav-wrap">
          <nav class="nav-links" aria-label="Main navigation">${desktopLinks}</nav>
          <div class="nav-actions">
            <button type="button" id="saved-btn-desktop" class="icon-heart-btn" title="Saved pets" aria-label="Saved pets">
              ${icon('heart-nav')}${badgeHtml}
            </button>
            ${authButton}
          </div>
        </div>

        <div class="mobile-nav-controls">
          <button type="button" id="saved-btn-mobile" class="icon-heart-btn" aria-label="Saved pets">
            ${icon('heart-nav')}${badgeHtml}
          </button>
          <button type="button" id="mobile-menu-toggle" class="menu-toggle-btn" aria-label="Toggle navigation menu" aria-expanded="${state.mobileMenuOpen}">
            ${icon('menu')}
          </button>
        </div>
      </div>

      <div id="mobile-drawer" class="mobile-drawer${state.mobileMenuOpen ? '' : ' hidden'}">
        <div class="mobile-nav-grid">${mobileLinks}</div>
        <div class="mobile-drawer-footer">
          <button type="button" id="auth-btn-mobile" class="btn btn-primary btn-full">${escapeHtml(authMobileText)}</button>
        </div>
      </div>
    `;
  }

  function renderFooter() {
    const footer = document.getElementById('site-footer');
    if (!footer) return;

    footer.innerHTML = `
      <div class="container footer-inner">
        <div class="footer-grid">
          <div class="footer-brand-col">
            <div class="footer-logo">
              ${icon('paw')}
              <span class="footer-brand-name">FurEver</span>
            </div>
            <p class="footer-desc">
              A thoughtful pet adoption and matching platform connecting loving families with verified shelter companions.
            </p>
          </div>

          <div class="footer-support-col">
            <h3 class="footer-heading">Adoption Support</h3>
            <div class="footer-contact-list">
              <p class="footer-contact-item">${icon('mail')}<a href="mailto:support@furever.com">support@furever.com</a></p>
              <p class="footer-contact-item">${icon('phone')}<a href="tel:18002347890">1800 234 7890</a></p>
              <p class="footer-contact-item">${icon('map-pin')}<span>Pune, Maharashtra</span></p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // Builds a single Pet Card used on Home, Browse, Quiz, and Status pages
  function renderPetCardHtml(pet) {
    const isFav = state.favouriteIds.includes(pet.id);
    const statusLabel =
      pet.status === 'AVAILABLE' ? 'Available' : pet.status === 'PENDING' ? 'Under Review' : 'Adopted';
    const statusClass =
      pet.status === 'AVAILABLE' ? '' : pet.status === 'PENDING' ? ' pending' : ' adopted';

    return `
      <article class="pet-card">
        <div class="pet-card-media">
          <img src="${escapeHtml(pet.primary_image_url)}" alt="${escapeHtml(`${pet.name} (${pet.breed})`)}" loading="lazy" />
          <button type="button" class="pet-fav-btn" data-fav-pet="${escapeHtml(pet.id)}" aria-label="Toggle favourite">
            ${icon(isFav ? 'heart-filled' : 'heart')}
          </button>
        </div>
        <div class="pet-card-body">
          <div>
            <div class="pet-card-top">
              <h3 class="pet-card-name">${escapeHtml(pet.name)}</h3>
              <span class="status-badge${statusClass}">${escapeHtml(statusLabel)}</span>
            </div>
            <p class="pet-card-breed">${escapeHtml(`${pet.breed} · ${pet.age_label}`)}</p>
            <p class="pet-card-loc">${icon('map-pin')}<span>${escapeHtml(pet.location)}</span></p>
          </div>
          <button type="button" class="btn btn-secondary btn-full" data-view-pet="${escapeHtml(pet.id)}">View Details</button>
        </div>
      </article>
    `;
  }

  function updateFavouriteButtonsInDom() {
    document.querySelectorAll('[data-fav-pet]').forEach((btn) => {
      const petId = btn.getAttribute('data-fav-pet');
      const isFav = state.favouriteIds.includes(petId);
      if (btn.classList.contains('pet-fav-btn')) {
        btn.innerHTML = icon(isFav ? 'heart-filled' : 'heart');
      } else {
        btn.innerHTML = `${icon(isFav ? 'heart-filled' : 'heart')}<span>${isFav ? 'Saved' : 'Save'}</span>`;
      }
    });
  }

  async function toggleFavourite(petId) {
    try {
      const res = await apiRequest('/favorites/toggle', {
        method: 'POST',
        body: JSON.stringify({ petId }),
      });
      state.favouriteIds = res.petIds || [];
      renderNavbar();
      updateFavouriteButtonsInDom();
      showToast(res.liked ? 'Added to saved favourites.' : 'Removed from favourites.');
      if (typeof state.onDataChanged === 'function') state.onDataChanged('favorites');
    } catch (err) {
      showToast(err.message);
    }
  }

  /* --------------------------------------------------------------------------
   * 4. MODALS (Pet Details, Adoption Form, Create Account / Login, Saved List)
   * -------------------------------------------------------------------------- */

  function closeModal() {
    const root = document.getElementById('modal-root');
    if (root) root.innerHTML = '';
  }

  function openPetModal(petId) {
    const pet = state.pets.find((p) => p.id === petId);
    if (!pet) return;

    const images =
      pet.images && pet.images.length > 0
        ? pet.images
        : [{ id: 'main', image_url: pet.primary_image_url, caption: pet.name }];
    const isFav = state.favouriteIds.includes(pet.id);

    const thumbsHtml =
      images.length > 1
        ? `<div class="gallery-thumbs">
            ${images
              .map(
                (img, idx) => `
                  <button type="button" class="gallery-thumb-btn${idx === 0 ? ' active' : ''}" data-gallery-src="${escapeHtml(img.image_url)}">
                    <img src="${escapeHtml(img.image_url)}" alt="${escapeHtml(img.caption || pet.name)}" />
                  </button>`
              )
              .join('')}
          </div>`
        : '';

    const shelterEmail = (pet.lister && pet.lister.email) || 'support@furever.com';
    const mailHref = `mailto:${encodeURIComponent(shelterEmail)}?subject=${encodeURIComponent(`Adoption Inquiry for ${pet.name}`)}`;

    document.getElementById('modal-root').innerHTML = `
      <div class="modal-backdrop" id="modal-backdrop">
        <div class="modal-dialog modal-xl" role="dialog" aria-modal="true">
          <button type="button" class="modal-close" id="modal-close-btn" aria-label="Close">${icon('x')}</button>

          <div class="modal-two-col">
            <div class="stack-sm">
              <div class="pet-card-media" style="border-radius:12px;border:1px solid #DCD1F5;">
                <img id="pet-modal-main-img" src="${escapeHtml(images[0].image_url)}" alt="${escapeHtml(pet.name)}" />
              </div>
              ${thumbsHtml}
              <div class="health-box stack-sm" style="gap:8px;">
                <p style="font-weight:600;display:flex;align-items:center;gap:6px;">
                  ${icon('shield')}<span>Health &amp; Vaccination Record</span>
                </p>
                <div class="grid-2" style="gap:6px;">
                  <span>${pet.vaccinated ? '✓ Vaccinated' : '• Pending vaccine'}</span>
                  <span>${pet.spayed_neutered ? '✓ Spayed / Neutered' : '• Not spayed'}</span>
                  <span>${pet.microchipped ? '✓ Microchipped' : '• No microchip'}</span>
                  <span>Fee: ${escapeHtml(pet.adoption_fee)}</span>
                </div>
                <p>${escapeHtml(pet.health_notes)}</p>
              </div>
            </div>

            <div class="stack-md" style="gap:16px;">
              <div>
                <span class="pill-badge">${escapeHtml(pet.status)}</span>
                <h2 style="font-size:24px;font-weight:600;margin-top:8px;">${escapeHtml(pet.name)}</h2>
                <p style="font-size:14px;">${escapeHtml(`${pet.breed} · ${pet.species} · ${pet.gender} · ${pet.age_label} · ${pet.weight}`)}</p>
                <p style="font-size:12px;margin-top:6px;display:flex;align-items:center;gap:6px;">
                  ${icon('map-pin')}<span>${escapeHtml(`${pet.location} (${pet.shelter_name})`)}</span>
                </p>
              </div>

              <p style="font-size:14px;">${escapeHtml(pet.description)}</p>

              <div style="font-size:14px;" class="stack-sm">
                <p><strong>Personality:</strong> ${escapeHtml((pet.personality_json || []).join(', '))}</p>
                <p><strong>Good with:</strong> ${escapeHtml((pet.good_with_json || []).join(', '))}</p>
              </div>

              <div class="req-box">
                <strong>Adoption Requirements:</strong> ${escapeHtml(pet.adoption_requirements || 'Loving indoor home and regular veterinary checkups.')}
              </div>

              <div class="btn-group">
                ${
                  pet.status === 'AVAILABLE'
                    ? `<button type="button" class="btn btn-primary" id="open-apply-modal-btn" data-pet-id="${escapeHtml(pet.id)}">Apply to Adopt</button>`
                    : `<button type="button" class="btn btn-soft" disabled>Currently ${escapeHtml(pet.status)}</button>`
                }
                <button type="button" class="btn btn-white" data-fav-pet="${escapeHtml(pet.id)}">
                  ${icon(isFav ? 'heart-filled' : 'heart')}<span>${isFav ? 'Saved' : 'Save'}</span>
                </button>
                <a href="${mailHref}" class="btn btn-soft">${icon('mail')}<span>Contact Shelter</span></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function openApplyModal(petId) {
    const pet = state.pets.find((p) => p.id === petId);
    if (!pet) return;

    const u = state.user;
    const housingOptions = ['House with Yard', 'Apartment', 'Independent House', 'Farm / Villa']
      .map((opt) => `<option value="${opt}"${u && u.housing_type === opt ? ' selected' : ''}>${opt}</option>`)
      .join('');

    document.getElementById('modal-root').innerHTML = `
      <div class="modal-backdrop" id="modal-backdrop">
        <div class="modal-dialog modal-lg" role="dialog" aria-modal="true">
          <button type="button" class="modal-close" id="modal-close-btn" aria-label="Close">${icon('x')}</button>
          <h2 style="font-size:24px;font-weight:600;">Adoption Application</h2>
          <p style="font-size:14px;margin:4px 0 20px;">
            Applying for <strong>${escapeHtml(pet.name)}</strong> (${escapeHtml(`${pet.breed} · ${pet.shelter_name}`)})
          </p>

          <form id="adoption-apply-form" data-pet-id="${escapeHtml(pet.id)}" class="stack-md" style="gap:16px;">
            <div class="grid-2">
              <div><label class="field-label">Full Name *</label><input name="applicantName" required value="${escapeHtml(u ? u.full_name : '')}" placeholder="Your full name" class="field-input" /></div>
              <div><label class="field-label">Email *</label><input type="email" name="applicantEmail" required value="${escapeHtml(u ? u.email : '')}" placeholder="you@example.com" class="field-input" /></div>
              <div><label class="field-label">Phone *</label><input name="applicantPhone" required value="${escapeHtml(u ? u.phone : '')}" placeholder="+91 98xxx xxxxx" class="field-input" /></div>
              <div><label class="field-label">City *</label><input name="city" required value="${escapeHtml((u && u.city) || 'Pune')}" class="field-input" /></div>
              <div><label class="field-label">Living Arrangement *</label><select name="housingType" class="field-select">${housingOptions}</select></div>
              <div>
                <label class="field-label">Previous Pet Experience *</label>
                <select name="petExperience" class="field-select">
                  <option value="Previous pet owner">Previous pet owner</option>
                  <option value="Experienced owner">Experienced owner</option>
                  <option value="First-time adopter">First-time adopter</option>
                </select>
              </div>
              <div><label class="field-label">Household Members</label><input name="householdMembers" value="2 Adults" class="field-input" /></div>
              <div>
                <label class="field-label">Hours Pet Alone Daily</label>
                <select name="dailyAloneHours" class="field-select">
                  <option value="0-2 hours">0–2 hours</option>
                  <option value="2-4 hours">2–4 hours</option>
                  <option value="4-6 hours">4–6 hours</option>
                  <option value="6+ hours">6+ hours</option>
                </select>
              </div>
            </div>

            <label class="checkbox-label" style="font-size:14px;">
              <input type="checkbox" name="hasYard" value="1" />
              <span>Home has a fenced yard or netted balcony</span>
            </label>

            <div>
              <label class="field-label">Why would your home be a good fit for ${escapeHtml(pet.name)}? (Min 20 words) *</label>
              <textarea name="fitReason" id="apply-fit-reason" required rows="4" placeholder="Share your daily routine, family experience, and living setup..." class="field-textarea"></textarea>
              <p id="apply-word-count" style="font-size:12px;font-weight:500;margin-top:4px;">0 / 20 words minimum</p>
            </div>

            <div class="btn-group" style="justify-content:flex-end;">
              <button type="button" class="btn btn-white btn-sm" id="modal-cancel-btn">Cancel</button>
              <button type="submit" class="btn btn-primary" id="apply-submit-btn">Submit Application</button>
            </div>
          </form>
        </div>
      </div>
    `;
  }

  function openAuthModal(activeMode = 'register') {
    const registerForm = `
      <form id="auth-register-form" class="stack-sm" style="gap:14px;">
        <div><label class="field-label">Full Name *</label><input name="fullName" required placeholder="e.g. Samiksha Padwal" class="field-input" /></div>
        <div><label class="field-label">Email *</label><input type="email" name="email" required placeholder="you@example.com" class="field-input" /></div>
        <div><label class="field-label">Password (min 6 characters) *</label><input type="password" name="password" required minlength="6" placeholder="Create a password" class="field-input" /></div>
        <div class="grid-2">
          <div>
            <label class="field-label">Role</label>
            <select name="role" class="field-select">
              <option value="adopter">Adopter</option>
              <option value="lister">Pet Shelter / Lister</option>
            </select>
          </div>
          <div><label class="field-label">City</label><input name="city" value="Pune" class="field-input" /></div>
        </div>
        <button type="submit" class="btn btn-primary btn-full" id="auth-submit-btn">Create Account</button>
      </form>
    `;

    const loginForm = `
      <form id="auth-login-form" class="stack-sm" style="gap:14px;">
        <div><label class="field-label">Email</label><input type="email" name="email" required placeholder="you@example.com" class="field-input" /></div>
        <div><label class="field-label">Password</label><input type="password" name="password" required placeholder="Enter your password" class="field-input" /></div>
        <button type="submit" class="btn btn-primary btn-full" id="auth-submit-btn">Login</button>
      </form>
      <div style="margin-top:20px;padding-top:16px;border-top:1px solid #DCD1F5;">
        <p style="font-size:12px;font-weight:500;margin-bottom:10px;">Quick SQL Demo Accounts (Password: furever123)</p>
        <div class="btn-group">
          <button type="button" class="btn btn-secondary btn-xs" data-demo-login="adopter@furever.com">Adopter</button>
          <button type="button" class="btn btn-secondary btn-xs" data-demo-login="shelter@furever.com">Pet Shelter</button>
          <button type="button" class="btn btn-soft btn-xs" data-demo-login="admin@furever.com">Admin</button>
        </div>
      </div>
    `;

    document.getElementById('modal-root').innerHTML = `
      <div class="modal-backdrop" id="modal-backdrop">
        <div class="modal-dialog modal-sm" role="dialog" aria-modal="true">
          <button type="button" class="modal-close" id="modal-close-btn" aria-label="Close">${icon('x')}</button>
          <h2 style="font-size:24px;font-weight:600;margin-bottom:4px;">${activeMode === 'register' ? 'Create Account' : 'Login to FurEver'}</h2>
          <p style="font-size:12px;margin-bottom:16px;">Saved directly to the Express + SQL users table (no JWT token used).</p>
          <div class="segmented-tabs">
            <button type="button" class="segmented-tab${activeMode === 'register' ? ' active' : ''}" data-auth-mode="register">Create Account</button>
            <button type="button" class="segmented-tab${activeMode === 'login' ? ' active' : ''}" data-auth-mode="login">Login</button>
          </div>
          ${activeMode === 'register' ? registerForm : loginForm}
        </div>
      </div>
    `;
  }

  function openSavedModal() {
    const savedPets = state.pets.filter((p) => state.favouriteIds.includes(p.id));

    const bodyHtml =
      savedPets.length === 0
        ? `<div style="text-align:center;padding:32px 0;" class="stack-sm">
            <p style="font-size:14px;">You haven't saved any pets yet.</p>
            <div><a href="/swipe.html" class="btn btn-primary btn-sm">Try Swipe Match</a></div>
          </div>`
        : `<div class="stack-sm">
            ${savedPets
              .map(
                (pet) => `
                  <div class="saved-row">
                    <div style="display:flex;align-items:center;gap:12px;">
                      <img src="${escapeHtml(pet.primary_image_url)}" alt="${escapeHtml(pet.name)}" style="width:56px;height:56px;border-radius:8px;object-fit:cover;border:1px solid #DCD1F5;" />
                      <div>
                        <p style="font-weight:600;font-size:14px;">${escapeHtml(pet.name)}</p>
                        <p style="font-size:12px;">${escapeHtml(`${pet.breed} · ${pet.age_label}`)}</p>
                      </div>
                    </div>
                    <div class="btn-group">
                      <button type="button" class="btn btn-primary btn-xs" data-view-pet="${escapeHtml(pet.id)}">View</button>
                      <button type="button" class="btn btn-white btn-xs" data-remove-saved="${escapeHtml(pet.id)}">Remove</button>
                    </div>
                  </div>`
              )
              .join('')}
          </div>`;

    document.getElementById('modal-root').innerHTML = `
      <div class="modal-backdrop" id="modal-backdrop">
        <div class="modal-dialog modal-md" role="dialog" aria-modal="true">
          <button type="button" class="modal-close" id="modal-close-btn" aria-label="Close">${icon('x')}</button>
          <h2 style="font-size:20px;font-weight:600;margin-bottom:16px;">Saved Favourites (${savedPets.length})</h2>
          ${bodyHtml}
        </div>
      </div>
    `;
  }

  async function activateUserSession(user, favouriteIds) {
    setActiveUserId(user.id);
    state.user = user;
    state.favouriteIds = favouriteIds || [];
    closeModal();
    await loadUserDashboardData();
    renderNavbar();
    if (typeof state.onDataChanged === 'function') state.onDataChanged('auth');
    showToast(`Active account: ${user.full_name}`);
  }

  async function signOutUser() {
    try {
      await apiRequest('/auth/logout', { method: 'POST' });
    } catch (_err) {
      // Ignore if already signed out
    }
    setActiveUserId('');
    state.user = null;
    await loadUserDashboardData();
    renderNavbar();
    if (typeof state.onDataChanged === 'function') state.onDataChanged('auth');
    showToast('Switched back to guest mode.');
  }

  /* --------------------------------------------------------------------------
   * 5. GLOBAL EVENT HANDLERS (Navbar, Pet Cards, Modals)
   * -------------------------------------------------------------------------- */

  document.addEventListener('click', async (e) => {
    const target = e.target;

    if (target.closest('#mobile-menu-toggle')) {
      state.mobileMenuOpen = !state.mobileMenuOpen;
      renderNavbar();
      return;
    }

    if (target.closest('#saved-btn-desktop') || target.closest('#saved-btn-mobile')) {
      openSavedModal();
      return;
    }

    if (target.closest('#auth-btn-desktop') || target.closest('#auth-btn-mobile')) {
      state.mobileMenuOpen = false;
      renderNavbar();
      openAuthModal('register');
      return;
    }

    if (target.id === 'modal-backdrop' || target.closest('#modal-close-btn') || target.closest('#modal-cancel-btn')) {
      closeModal();
      return;
    }

    const viewPetEl = target.closest('[data-view-pet]');
    if (viewPetEl && !target.closest('[data-fav-pet]')) {
      openPetModal(viewPetEl.getAttribute('data-view-pet'));
      return;
    }

    const favEl = target.closest('[data-fav-pet]');
    if (favEl) {
      toggleFavourite(favEl.getAttribute('data-fav-pet'));
      return;
    }

    const removeSavedEl = target.closest('[data-remove-saved]');
    if (removeSavedEl) {
      await toggleFavourite(removeSavedEl.getAttribute('data-remove-saved'));
      openSavedModal();
      return;
    }

    const galleryEl = target.closest('[data-gallery-src]');
    if (galleryEl) {
      const mainImg = document.getElementById('pet-modal-main-img');
      if (mainImg) mainImg.src = galleryEl.getAttribute('data-gallery-src');
      document.querySelectorAll('.gallery-thumb-btn').forEach((b) => b.classList.remove('active'));
      galleryEl.classList.add('active');
      return;
    }

    const applyBtn = target.closest('#open-apply-modal-btn');
    if (applyBtn) {
      openApplyModal(applyBtn.getAttribute('data-pet-id'));
      return;
    }

    const authModeBtn = target.closest('[data-auth-mode]');
    if (authModeBtn) {
      openAuthModal(authModeBtn.getAttribute('data-auth-mode'));
      return;
    }

    const demoBtn = target.closest('[data-demo-login]');
    if (demoBtn) {
      try {
        const res = await apiRequest('/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email: demoBtn.getAttribute('data-demo-login'), password: 'furever123' }),
        });
        await activateUserSession(res.user, res.favouriteIds);
      } catch (err) {
        showToast(err.message);
      }
    }
  });

  // Live 20-word counter in the Adoption Application form
  document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'apply-fit-reason') {
      const words = e.target.value.trim().split(/\s+/).filter(Boolean).length;
      const counter = document.getElementById('apply-word-count');
      if (counter) {
        counter.textContent = `${words} / 20 words minimum${words >= 20 ? ' ✓' : ''}`;
      }
    }
  });

  // Modal Form Submissions: Register, Login, and Adoption Application
  document.addEventListener('submit', async (e) => {
    const form = e.target;

    if (form.id === 'auth-register-form') {
      e.preventDefault();
      const fd = new FormData(form);
      const btn = document.getElementById('auth-submit-btn');
      if (btn) btn.disabled = true;
      try {
        const res = await apiRequest('/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            fullName: String(fd.get('fullName') || ''),
            email: String(fd.get('email') || ''),
            password: String(fd.get('password') || ''),
            role: String(fd.get('role') || 'adopter'),
            city: String(fd.get('city') || 'Pune'),
          }),
        });
        await activateUserSession(res.user, res.favouriteIds);
      } catch (err) {
        showToast(err.message);
      } finally {
        if (btn) btn.disabled = false;
      }
    } else if (form.id === 'auth-login-form') {
      e.preventDefault();
      const fd = new FormData(form);
      const btn = document.getElementById('auth-submit-btn');
      if (btn) btn.disabled = true;
      try {
        const res = await apiRequest('/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            email: String(fd.get('email') || ''),
            password: String(fd.get('password') || ''),
          }),
        });
        await activateUserSession(res.user, res.favouriteIds);
      } catch (err) {
        showToast(err.message);
      } finally {
        if (btn) btn.disabled = false;
      }
    } else if (form.id === 'adoption-apply-form') {
      e.preventDefault();
      const fd = new FormData(form);
      const btn = document.getElementById('apply-submit-btn');
      if (btn) btn.disabled = true;
      try {
        const res = await apiRequest('/applications', {
          method: 'POST',
          body: JSON.stringify({
            petId: form.getAttribute('data-pet-id'),
            applicantName: fd.get('applicantName'),
            applicantEmail: fd.get('applicantEmail'),
            applicantPhone: fd.get('applicantPhone'),
            city: fd.get('city'),
            housingType: fd.get('housingType'),
            hasYard: fd.get('hasYard') === '1',
            petExperience: fd.get('petExperience'),
            householdMembers: fd.get('householdMembers'),
            dailyAloneHours: fd.get('dailyAloneHours'),
            fitReason: fd.get('fitReason'),
          }),
        });
        closeModal();
        await Promise.all([loadPublicData(), loadUserDashboardData()]);
        renderNavbar();
        if (typeof state.onDataChanged === 'function') state.onDataChanged('application');
        showToast(
          res.eligibility.result === 'APPLICABLE'
            ? 'Application submitted and eligibility verified!'
            : 'Application submitted for shelter review.'
        );
      } catch (err) {
        showToast(err.message);
      } finally {
        if (btn) btn.disabled = false;
      }
    }
  });

  /* --------------------------------------------------------------------------
   * 6. PAGE BOOTSTRAPPER (Called by every page JS file)
   * -------------------------------------------------------------------------- */

  async function initPage(pageId, onReady, onDataChanged) {
    state.currentPage = pageId;
    state.onDataChanged = onDataChanged || null;
    renderNavbar();
    renderFooter();
    try {
      await Promise.all([loadPublicData(), loadUserDashboardData()]);
    } catch (err) {
      showToast(`Failed to load FurEver data: ${err.message}`);
    }
    renderNavbar();
    if (typeof onReady === 'function') onReady();
  }

  return {
    state,
    escapeHtml,
    icon,
    showToast,
    apiRequest,
    loadPublicData,
    loadUserDashboardData,
    renderNavbar,
    renderPetCardHtml,
    openAuthModal,
    openSavedModal,
    signOutUser,
    initPage,
  };
})();
