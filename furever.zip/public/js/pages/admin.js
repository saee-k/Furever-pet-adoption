/*
 * ============================================================================
 * FurEver — Admin Dashboard Page Script (public/admin.html)
 * ============================================================================
 * Requires an admin account (role === 'admin', e.g., admin@furever.com).
 * Provides 4 management tabs: Applications, Pets, Users, and Vet Clinics.
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  const adminState = {
    data: null,
    activeTab: 'applications',
  };

  async function loadAdminData() {
    if (!App.state.user || App.state.user.role !== 'admin') {
      adminState.data = null;
      renderAdmin();
      return;
    }
    try {
      adminState.data = await App.apiRequest('/admin/dashboard');
      renderAdmin();
    } catch (err) {
      App.showToast(err.message);
    }
  }

  function renderApplicationsTable(applications) {
    const rows = applications
      .map(
        (a) => `
          <tr>
            <td style="font-weight:500;">${App.escapeHtml(a.pet_name)}</td>
            <td>${App.escapeHtml(a.applicant_name)}<div style="font-size:12px;">${App.escapeHtml(a.applicant_email)}</div></td>
            <td>${App.escapeHtml(a.housing_type)}</td>
            <td>${App.escapeHtml(a.status)}</td>
            <td>
              <div class="btn-group">
                <button type="button" class="btn btn-primary btn-xs" data-admin-app="${App.escapeHtml(a.id)}" data-status="Approved">Approve</button>
                <button type="button" class="btn btn-soft btn-xs" data-admin-app="${App.escapeHtml(a.id)}" data-status="Rejected">Reject</button>
              </div>
            </td>
          </tr>`
      )
      .join('');

    return `
      <div class="table-card">
        <table class="data-table">
          <thead><tr><th>Pet</th><th>Applicant</th><th>Housing</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
  }

  function renderPetsTable(pets) {
    const rows = pets
      .map((p) => {
        const nextStatus = p.status === 'AVAILABLE' ? 'ADOPTED' : 'AVAILABLE';
        return `
          <tr>
            <td style="font-weight:500;">${App.escapeHtml(p.name)}</td>
            <td>${App.escapeHtml(`${p.species} · ${p.breed}`)}</td>
            <td>${App.escapeHtml(p.location)}</td>
            <td>${App.escapeHtml(p.status)}</td>
            <td>
              <div class="btn-group">
                <button type="button" class="btn btn-secondary btn-xs" data-admin-pet-status="${App.escapeHtml(p.id)}" data-next="${nextStatus}">
                  Mark ${p.status === 'AVAILABLE' ? 'Adopted' : 'Available'}
                </button>
                <button type="button" class="btn btn-soft btn-xs" data-admin-delete-pet="${App.escapeHtml(p.id)}">Delete</button>
              </div>
            </td>
          </tr>`;
      })
      .join('');

    return `
      <div class="table-card">
        <table class="data-table">
          <thead><tr><th>Name</th><th>Breed</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
  }

  function renderUsersTable(users) {
    const rows = users
      .map(
        (u) => `
          <tr>
            <td style="font-weight:500;">${App.escapeHtml(u.full_name)}</td>
            <td>${App.escapeHtml(u.email)}</td>
            <td style="text-transform:capitalize;">${App.escapeHtml(u.role)}</td>
            <td>${u.is_active ? 'Active' : 'Suspended'}</td>
            <td>
              <button type="button" class="btn btn-soft btn-xs" data-admin-user="${App.escapeHtml(u.id)}" data-active="${u.is_active ? '0' : '1'}">
                ${u.is_active ? 'Deactivate' : 'Activate'}
              </button>
            </td>
          </tr>`
      )
      .join('');

    return `
      <div class="table-card">
        <table class="data-table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
  }

  function renderVetsSection(vets) {
    const rows = vets
      .map(
        (v) => `
          <tr>
            <td style="font-weight:500;">${App.escapeHtml(v.clinic_name)}</td>
            <td>${App.escapeHtml(v.vet_name)}</td>
            <td>${App.escapeHtml(v.city)}</td>
            <td>${App.escapeHtml(v.phone)}</td>
            <td><button type="button" class="btn btn-soft btn-xs" data-admin-delete-vet="${App.escapeHtml(v.id)}">Delete</button></td>
          </tr>`
      )
      .join('');

    return `
      <div class="stack-md">
        <form id="admin-add-vet-form" class="panel-card grid-3" style="align-items:end;">
          <input name="clinicName" required placeholder="Clinic Name *" class="field-input" />
          <input name="vetName" required placeholder="Veterinarian Name *" class="field-input" />
          <input name="city" required value="Pune" placeholder="City / Area *" class="field-input" />
          <input name="address" required placeholder="Street Address *" class="field-input" />
          <input name="phone" required placeholder="Phone *" class="field-input" />
          <button type="submit" class="btn btn-primary btn-sm">Add Clinic</button>
        </form>
        <div class="table-card">
          <table class="data-table">
            <thead><tr><th>Clinic</th><th>Veterinarian</th><th>Area</th><th>Phone</th><th>Action</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  function renderAdmin() {
    const container = document.getElementById('admin-container');
    if (!container) return;

    if (!App.state.user || App.state.user.role !== 'admin') {
      container.className = 'container-xs section-pad';
      container.innerHTML = `
        <div class="empty-card">
          <h1 style="font-size:24px;font-weight:600;margin-bottom:12px;">Administrator Access Required</h1>
          <p style="font-size:14px;margin-bottom:18px;">
            Sign in with an administrator account (admin@furever.com) to manage platform listings, users, and applications.
          </p>
          <button type="button" class="btn btn-primary" id="admin-open-auth-btn">Sign In as Admin</button>
        </div>
      `;
      return;
    }

    const d = adminState.data;
    if (!d) {
      container.className = 'container section-pad';
      container.innerHTML = '<p style="font-size:14px;">Loading admin dashboard...</p>';
      return;
    }

    const tabs = [
      ['applications', `Applications (${d.applications.length})`],
      ['pets', `Pets (${d.pets.length})`],
      ['users', `Users (${d.users.length})`],
      ['vets', `Vets (${d.vets.length})`],
    ];

    const tabButtons = tabs
      .map(
        ([id, label]) =>
          `<button type="button" class="chip-btn${adminState.activeTab === id ? ' active' : ''}" data-admin-tab="${id}">${App.escapeHtml(label)}</button>`
      )
      .join('');

    const activeBody =
      adminState.activeTab === 'applications'
        ? renderApplicationsTable(d.applications)
        : adminState.activeTab === 'pets'
        ? renderPetsTable(d.pets)
        : adminState.activeTab === 'users'
        ? renderUsersTable(d.users)
        : renderVetsSection(d.vets);

    container.className = 'container section-pad stack-lg';
    container.innerHTML = `
      <div class="page-header" style="margin-bottom:0;">
        <div>
          <h1 class="page-title">Admin Dashboard</h1>
          <p class="page-subtitle">Manage users, pet listings, adoption applications, and clinics.</p>
        </div>
        <button type="button" class="btn btn-white btn-sm" id="admin-refresh-btn">Refresh</button>
      </div>

      <div class="stats-grid">
        <div class="stat-card"><p class="stat-val tabular-nums">${d.stats.totalUsers}</p><p style="font-size:12px;margin-top:4px;">Registered Users</p></div>
        <div class="stat-card"><p class="stat-val tabular-nums">${d.stats.totalPets}</p><p style="font-size:12px;margin-top:4px;">Pet Listings</p></div>
        <div class="stat-card"><p class="stat-val tabular-nums">${d.stats.pendingApplications}</p><p style="font-size:12px;margin-top:4px;">Pending Applications</p></div>
        <div class="stat-card"><p class="stat-val tabular-nums">${d.vets.length}</p><p style="font-size:12px;margin-top:4px;">Verified Clinics</p></div>
      </div>

      <div class="chip-row" style="margin-bottom:0;">${tabButtons}</div>
      ${activeBody}
    `;
  }

  document.addEventListener('click', async (e) => {
    if (e.target.closest('#admin-open-auth-btn')) {
      App.openAuthModal('login');
      return;
    }
    if (e.target.closest('#admin-refresh-btn')) {
      loadAdminData();
      return;
    }

    const tabEl = e.target.closest('[data-admin-tab]');
    if (tabEl) {
      adminState.activeTab = tabEl.getAttribute('data-admin-tab');
      renderAdmin();
      return;
    }

    const appEl = e.target.closest('[data-admin-app]');
    if (appEl) {
      const id = appEl.getAttribute('data-admin-app');
      const status = appEl.getAttribute('data-status');
      try {
        await App.apiRequest(`/applications/${encodeURIComponent(id)}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status, reviewerNotes: '' }),
        });
        await Promise.all([loadAdminData(), App.loadPublicData(), App.loadUserDashboardData()]);
        App.showToast(`Application ${status.toLowerCase()}.`);
      } catch (err) {
        App.showToast(err.message);
      }
      return;
    }

    const petStatusEl = e.target.closest('[data-admin-pet-status]');
    if (petStatusEl) {
      const id = petStatusEl.getAttribute('data-admin-pet-status');
      const next = petStatusEl.getAttribute('data-next');
      try {
        await App.apiRequest(`/pets/${encodeURIComponent(id)}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: next }),
        });
        await Promise.all([loadAdminData(), App.loadPublicData(), App.loadUserDashboardData()]);
        App.showToast(`Pet marked as ${next}.`);
      } catch (err) {
        App.showToast(err.message);
      }
      return;
    }

    const deletePetEl = e.target.closest('[data-admin-delete-pet]');
    if (deletePetEl) {
      const id = deletePetEl.getAttribute('data-admin-delete-pet');
      try {
        await App.apiRequest(`/pets/${encodeURIComponent(id)}`, { method: 'DELETE' });
        await Promise.all([loadAdminData(), App.loadPublicData(), App.loadUserDashboardData()]);
        App.showToast('Pet listing removed.');
      } catch (err) {
        App.showToast(err.message);
      }
      return;
    }

    const userEl = e.target.closest('[data-admin-user]');
    if (userEl) {
      const id = userEl.getAttribute('data-admin-user');
      const isActive = userEl.getAttribute('data-active') === '1';
      try {
        await App.apiRequest(`/admin/users/${encodeURIComponent(id)}`, {
          method: 'PATCH',
          body: JSON.stringify({ is_active: isActive }),
        });
        await loadAdminData();
        App.showToast('User status updated.');
      } catch (err) {
        App.showToast(err.message);
      }
      return;
    }

    const deleteVetEl = e.target.closest('[data-admin-delete-vet]');
    if (deleteVetEl) {
      const id = deleteVetEl.getAttribute('data-admin-delete-vet');
      try {
        await App.apiRequest(`/admin/vets/${encodeURIComponent(id)}`, { method: 'DELETE' });
        await Promise.all([loadAdminData(), App.loadPublicData()]);
        App.showToast('Veterinary clinic deleted.');
      } catch (err) {
        App.showToast(err.message);
      }
    }
  });

  document.addEventListener('submit', async (e) => {
    const form = e.target;
    if (!form || form.id !== 'admin-add-vet-form') return;

    e.preventDefault();
    const fd = new FormData(form);
    try {
      await App.apiRequest('/vets', {
        method: 'POST',
        body: JSON.stringify({
          clinicName: String(fd.get('clinicName') || ''),
          vetName: String(fd.get('vetName') || ''),
          city: String(fd.get('city') || ''),
          address: String(fd.get('address') || ''),
          phone: String(fd.get('phone') || ''),
        }),
      });
      form.reset();
      await Promise.all([loadAdminData(), App.loadPublicData()]);
      App.showToast('Veterinary clinic added.');
    } catch (err) {
      App.showToast(err.message);
    }
  });

  App.initPage('admin', loadAdminData, loadAdminData);
})();
