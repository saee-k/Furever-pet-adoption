/*
 * ============================================================================
 * FurEver — List a Pet Page Script (public/list-pet.html)
 * ============================================================================
 * Submits the multipart/form-data form (including optional photo upload)
 * directly to POST /api/pets, then redirects to Browse Pets.
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  function syncFormDefaults() {
    const user = App.state.user;
    const locInput = document.querySelector('#list-pet-form input[name="location"]');
    const shelterInput = document.querySelector('#list-pet-form input[name="shelterName"]');
    if (locInput && user && user.city) locInput.value = user.city;
    if (shelterInput && user && user.full_name) shelterInput.value = user.full_name;
  }

  document.addEventListener('submit', async (e) => {
    const form = e.target;
    if (!form || form.id !== 'list-pet-form') return;

    e.preventDefault();
    const btn = document.getElementById('list-pet-submit-btn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Publishing...';
    }

    try {
      await App.apiRequest('/pets', { method: 'POST', body: new FormData(form) });
      form.reset();
      App.showToast('Pet profile published successfully!');
      window.setTimeout(() => {
        window.location.href = '/browse.html';
      }, 700);
    } catch (err) {
      App.showToast(err.message);
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Publish Pet Listing';
      }
    }
  });

  App.initPage('list-pet', syncFormDefaults, syncFormDefaults);
})();
