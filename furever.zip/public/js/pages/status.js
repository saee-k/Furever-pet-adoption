/*
 * ============================================================================
 * FurEver — Status Dashboard Page Script (public/status.html)
 * ============================================================================
 * Displays the user's:
 *   1. Account header (Guest session vs signed-in user)
 *   2. Adoption Applications (with Approve/Reject for shelters, Withdraw for adopters)
 *   3. Profile Settings form & Notifications / Swipe History
 *   4. Saved Favourites & Listed Pets
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  function renderApplicationsSection(applications, canReview) {
    const title = canReview ? 'Incoming Adoption Applications' : 'Adoption Applications';
    if (applications.length === 0) {
      return `
        <div>
          <h2 style="font-size:20px;font-weight:600;margin-bottom:16px;">${title} (0)</h2>
          <div class="panel-card" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
            <p style="font-size:14px;">No adoption applications submitted yet.</p>
            <a href="/browse.html" class="btn btn-secondary btn-sm">Browse Pets</a>
          </div>
        </div>
      `;
    }

    const rowsHtml = applications
      .map((app) => {
        const isActionable = ['Pending', 'Under Review'].includes(app.status);
        let actions = `<span class="pill-badge">${App.escapeHtml(app.status)}</span>`;

        if (canReview && isActionable) {
          actions += `
            <button type="button" class="btn btn-primary btn-xs" data-app-status="${App.escapeHtml(app.id)}" data-next-status="Approved">Approve</button>
            <button type="button" class="btn btn-soft btn-xs" data-app-status="${App.escapeHtml(app.id)}" data-next-status="Rejected">Reject</button>
          `;
        } else if (!canReview && isActionable) {
          actions += `
            <button type="button" class="btn btn-white btn-xs" data-app-status="${App.escapeHtml(app.id)}" data-next-status="Withdrawn">Withdraw</button>
          `;
        }

        return `
          <div class="app-row">
            <div class="app-pet-info">
              <img src="${App.escapeHtml(app.pet_image || '/pets/goldie.jpg')}" alt="${App.escapeHtml(app.pet_name || 'Pet')}" class="app-thumb" />
              <div>
                <h3 style="font-size:16px;font-weight:600;">${App.escapeHtml(app.pet_name || 'Pet')}</h3>
                <p style="font-size:12px;">
                  Applicant: ${App.escapeHtml(app.applicant_name)} · ${App.escapeHtml(app.housing_type)} · Eligibility: ${App.escapeHtml(app.eligibility_result)}
                </p>
                <p style="font-size:12px;margin-top:4px;">${App.escapeHtml(app.eligibility_reason)}</p>
              </div>
            </div>
            <div class="btn-group" style="align-items:center;">${actions}</div>
          </div>
        `;
      })
      .join('');

    return `
      <div>
        <h2 style="font-size:20px;font-weight:600;margin-bottom:16px;">${title} (${applications.length})</h2>
        <div class="stack-sm">${rowsHtml}</div>
      </div>
    `;
  }

  function renderProfileForm(user) {
    if (!user) return '';
    const housingOptions = ['Apartment', 'House with Yard', 'Independent House']
      .map((h) => `<option value="${h}"${(user.housing_type || 'Apartment') === h ? ' selected' : ''}>${h}</option>`)
      .join('');

    return `
      <form id="profile-save-form" class="panel-card stack-md">
        <h2 style="font-size:18px;font-weight:600;">Profile Settings</h2>
        <div class="grid-2">
          <div><label class="field-label">Full Name</label><input name="fullName" required value="${App.escapeHtml(user.full_name)}" class="field-input" /></div>
          <div><label class="field-label">Phone</label><input name="phone" value="${App.escapeHtml(user.phone)}" class="field-input" /></div>
          <div><label class="field-label">City</label><input name="city" value="${App.escapeHtml(user.city)}" class="field-input" /></div>
          <div><label class="field-label">Housing Type</label><select name="housingType" class="field-select">${housingOptions}</select></div>
        </div>
        <div><button type="submit" class="btn btn-primary btn-sm" id="profile-save-btn">Save Profile</button></div>
      </form>
    `;
  }

  function renderActivityPanel(notifications, swipeHistory) {
    const notifHtml =
      notifications.length === 0
        ? '<p style="font-size:14px;">No new notifications.</p>'
        : `<div class="stack-sm">
            ${notifications
              .slice(0, 4)
              .map(
                (n) => `
                  <div class="notif-item">
                    <p style="font-weight:600;">${App.escapeHtml(n.title)}</p>
                    <p style="margin-top:2px;">${App.escapeHtml(n.message)}</p>
                  </div>`
              )
              .join('')}
          </div>`;

    const swipeHtml =
      swipeHistory.length === 0
        ? '<p style="font-size:12px;">No swipes recorded yet.</p>'
        : `<div class="stack-sm" style="gap:6px;font-size:12px;">
            ${swipeHistory
              .slice(0, 5)
              .map(
                (item) => `
                  <div style="display:flex;justify-content:space-between;">
                    <span>${App.escapeHtml(`${item.pet_name} (${item.species})`)}</span>
                    <span style="text-transform:capitalize;font-weight:500;">${App.escapeHtml(item.action)}</span>
                  </div>`
              )
              .join('')}
          </div>`;

    return `
      <div class="panel-card stack-md">
        <div>
          <h2 style="font-size:18px;font-weight:600;margin-bottom:10px;">Notifications</h2>
          ${notifHtml}
        </div>
        <div style="padding-top:12px;border-top:1px solid #DCD1F5;">
          <h3 style="font-size:14px;font-weight:600;margin-bottom:8px;">Recent Swipe History (${swipeHistory.length})</h3>
          ${swipeHtml}
        </div>
      </div>
    `;
  }

  function renderStatusDashboard() {
    const container = document.getElementById('status-container');
    if (!container) return;

    const { user, pets, applications, notifications, swipeHistory, favouriteIds } = App.state;
    const savedPets = pets.filter((p) => favouriteIds.includes(p.id));
    const listedPets = user ? pets.filter((p) => p.lister_id === user.id) : [];
    const canReview = Boolean(user && (user.role === 'lister' || user.role === 'admin'));

    container.innerHTML = `
      <div class="dashboard-header">
        <div>
          <p style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">
            ${user ? App.escapeHtml(`${user.role} Account`) : 'Guest SQL Session'}
          </p>
          <h1 class="page-title" style="margin-top:4px;">
            ${user ? `Welcome, ${App.escapeHtml(user.full_name)}` : 'Adoption Status &amp; Activity'}
          </h1>
          <p class="page-subtitle">
            ${
              user
                ? App.escapeHtml(`${user.email} · ${user.city || 'Pune'}`)
                : 'Browse freely without login, or create a personal account to keep your own SQL profile.'
            }
          </p>
        </div>

        <div class="btn-group">
          ${user && user.role === 'admin' ? '<a href="/admin.html" class="btn btn-primary btn-sm">Open Admin Dashboard</a>' : ''}
          <button type="button" class="btn btn-primary btn-sm" id="status-open-auth-btn">
            ${user ? 'Switch / Create Account' : 'Create Account / Login'}
          </button>
          ${user ? `<button type="button" class="btn btn-white btn-sm" id="status-logout-btn">${App.icon('logout')}<span>Sign Out</span></button>` : ''}
        </div>
      </div>

      ${renderApplicationsSection(applications, canReview)}

      <div class="${user ? 'grid-2' : ''}">
        ${renderProfileForm(user)}
        ${renderActivityPanel(notifications, swipeHistory)}
      </div>

      <div>
        <h2 style="font-size:20px;font-weight:600;margin-bottom:16px;">Saved Favourites (${savedPets.length})</h2>
        ${
          savedPets.length === 0
            ? '<p style="font-size:14px;">Click the heart icon on any pet card to save companions here.</p>'
            : `<div class="pet-grid">${savedPets.map(App.renderPetCardHtml).join('')}</div>`
        }
      </div>

      ${
        listedPets.length > 0
          ? `<div>
              <h2 style="font-size:20px;font-weight:600;margin-bottom:16px;">My Listed Pets (${listedPets.length})</h2>
              <div class="pet-grid">${listedPets.map(App.renderPetCardHtml).join('')}</div>
            </div>`
          : ''
      }
    `;
  }

  document.addEventListener('click', async (e) => {
    if (e.target.closest('#status-open-auth-btn')) {
      App.openAuthModal('register');
      return;
    }
    if (e.target.closest('#status-logout-btn')) {
      await App.signOutUser();
      return;
    }

    const appStatusBtn = e.target.closest('[data-app-status]');
    if (appStatusBtn) {
      const appId = appStatusBtn.getAttribute('data-app-status');
      const nextStatus = appStatusBtn.getAttribute('data-next-status');
      try {
        await App.apiRequest(`/applications/${encodeURIComponent(appId)}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: nextStatus, reviewerNotes: '' }),
        });
        await Promise.all([App.loadPublicData(), App.loadUserDashboardData()]);
        renderStatusDashboard();
        App.showToast(`Application status updated to ${nextStatus}.`);
      } catch (err) {
        App.showToast(err.message);
      }
    }
  });

  document.addEventListener('submit', async (e) => {
    const form = e.target;
    if (!form || form.id !== 'profile-save-form') return;

    e.preventDefault();
    const fd = new FormData(form);
    const btn = document.getElementById('profile-save-btn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Saving...';
    }
    try {
      const res = await App.apiRequest('/users/profile', {
        method: 'PUT',
        body: JSON.stringify({
          fullName: String(fd.get('fullName') || ''),
          phone: String(fd.get('phone') || ''),
          city: String(fd.get('city') || ''),
          housingType: String(fd.get('housingType') || 'Apartment'),
        }),
      });
      App.state.user = res.user;
      App.renderNavbar();
      renderStatusDashboard();
      App.showToast('Profile updated.');
    } catch (err) {
      App.showToast(err.message);
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Save Profile';
      }
    }
  });

  App.initPage('status', renderStatusDashboard, renderStatusDashboard);
})();
