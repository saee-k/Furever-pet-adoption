/*
 * ============================================================================
 * FurEver — Browse Pets Page Script (public/browse.html)
 * ============================================================================
 * Filters and sorts the loaded pets in real time by:
 *   - Species chip (All, Dog, Cat, Rabbit, Bird, Other)
 *   - Search keyword (name, breed, area, personality)
 *   - Age group, gender, Pune neighbourhood, and sort order
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  const filters = {
    search: '',
    species: 'All',
    ageCategory: 'All',
    gender: 'All',
    location: 'All',
    sortBy: 'featured',
  };

  function getFilteredPets() {
    const query = filters.search.trim().toLowerCase();

    return (App.state.pets || [])
      .filter((pet) => {
        if (filters.species !== 'All' && pet.species !== filters.species) return false;
        if (filters.ageCategory !== 'All' && pet.age_category !== filters.ageCategory) return false;
        if (filters.gender !== 'All' && pet.gender !== filters.gender) return false;
        if (filters.location !== 'All' && !pet.location.toLowerCase().includes(filters.location.toLowerCase())) {
          return false;
        }
        if (query) {
          const searchable = `${pet.name} ${pet.breed} ${pet.species} ${pet.location} ${pet.description} ${(pet.personality_json || []).join(' ')}`.toLowerCase();
          if (!searchable.includes(query)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === 'name') return a.name.localeCompare(b.name);
        if (filters.sortBy === 'oldest') return new Date(a.created_at) - new Date(b.created_at);
        return (b.is_featured || 0) - (a.is_featured || 0);
      });
  }

  function renderBrowseResults() {
    const area = document.getElementById('browse-results-area');
    if (!area) return;

    const filtered = getFilteredPets();
    const hasActiveFilter =
      filters.species !== 'All' ||
      filters.search ||
      filters.ageCategory !== 'All' ||
      filters.gender !== 'All' ||
      filters.location !== 'All';

    const metaRow = `
      <div class="results-meta">
        <span>Showing <strong class="tabular-nums">${filtered.length}</strong> companion${filtered.length === 1 ? '' : 's'}</span>
        ${hasActiveFilter ? '<button type="button" class="btn-link" id="reset-filters-link">Reset filters</button>' : ''}
      </div>
    `;

    const gridOrEmpty =
      filtered.length === 0
        ? `
          <div class="empty-card">
            <h3>No matching pets found</h3>
            <p class="page-subtitle" style="margin:6px 0 16px;">Try adjusting your search or clearing one of the filters.</p>
            <button type="button" class="btn btn-primary" id="show-all-pets-btn">Show All Pets</button>
          </div>
        `
        : `<div class="pet-grid">${filtered.map(App.renderPetCardHtml).join('')}</div>`;

    area.innerHTML = metaRow + gridOrEmpty;
  }

  function syncFilterControls() {
    document.querySelectorAll('[data-browse-species]').forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-browse-species') === filters.species);
    });
    const fieldMap = {
      'browse-search': filters.search,
      'browse-age': filters.ageCategory,
      'browse-gender': filters.gender,
      'browse-location': filters.location,
      'browse-sort': filters.sortBy,
    };
    Object.entries(fieldMap).forEach(([id, value]) => {
      const el = document.getElementById(id);
      if (el) el.value = value;
    });
  }

  function resetFilters() {
    filters.search = '';
    filters.species = 'All';
    filters.ageCategory = 'All';
    filters.gender = 'All';
    filters.location = 'All';
    filters.sortBy = 'featured';
    syncFilterControls();
    renderBrowseResults();
  }

  // Event Listeners
  document.addEventListener('click', (e) => {
    const spBtn = e.target.closest('[data-browse-species]');
    if (spBtn) {
      filters.species = spBtn.getAttribute('data-browse-species');
      syncFilterControls();
      renderBrowseResults();
      return;
    }
    if (e.target.closest('#reset-filters-link') || e.target.closest('#show-all-pets-btn')) {
      resetFilters();
    }
  });

  document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'browse-search') {
      filters.search = e.target.value;
      renderBrowseResults();
    }
  });

  document.addEventListener('change', (e) => {
    const target = e.target;
    if (!target) return;
    if (target.id === 'browse-age') filters.ageCategory = target.value;
    else if (target.id === 'browse-gender') filters.gender = target.value;
    else if (target.id === 'browse-location') filters.location = target.value;
    else if (target.id === 'browse-sort') filters.sortBy = target.value;
    else return;
    renderBrowseResults();
  });

  App.initPage('browse', renderBrowseResults, renderBrowseResults);
})();
