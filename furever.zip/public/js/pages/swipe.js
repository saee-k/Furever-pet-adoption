/*
 * ============================================================================
 * FurEver — Swipe Match Page Script (public/swipe.html)
 * ============================================================================
 * Displays one available pet card at a time.
 *   - Like (Heart): saves to SQL favourites & swipe_history via POST /api/swipes
 *   - Pass (X): skips pet and records pass in swipe_history
 *   - Undo: brings back the last swiped pet
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  const swipeState = {
    speciesPref: 'All',
    swipedIds: [],
    undoStack: [],
  };

  function getRemainingDeck() {
    return (App.state.pets || []).filter(
      (pet) =>
        pet.status === 'AVAILABLE' &&
        (swipeState.speciesPref === 'All' || pet.species === swipeState.speciesPref) &&
        !swipeState.swipedIds.includes(pet.id)
    );
  }

  function renderSwipeStage() {
    const savedTopBtn = document.getElementById('swipe-saved-top-btn');
    if (savedTopBtn) {
      savedTopBtn.textContent = `Saved Matches (${App.state.favouriteIds.length})`;
    }

    document.querySelectorAll('[data-swipe-species]').forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-swipe-species') === swipeState.speciesPref);
    });

    const stage = document.getElementById('swipe-stage');
    if (!stage) return;

    const deck = getRemainingDeck();
    const pet = deck[0];

    if (!pet) {
      stage.innerHTML = `
        <div class="empty-card">
          <h2 style="font-size:20px;font-weight:600;margin-bottom:10px;">You have viewed all pets in this deck</h2>
          <p style="font-size:14px;margin-bottom:18px;">
            You currently have ${App.state.favouriteIds.length} saved match${App.state.favouriteIds.length === 1 ? '' : 'es'}.
          </p>
          <div class="btn-group" style="justify-content:center;">
            <button type="button" class="btn btn-primary" id="swipe-open-saved-btn">View Saved Matches</button>
            <button type="button" class="btn btn-secondary" id="swipe-reset-btn">Start Over</button>
          </div>
        </div>
      `;
      return;
    }

    stage.innerHTML = `
      <div class="swipe-card">
        <div class="pet-card-media">
          <img src="${App.escapeHtml(pet.primary_image_url)}" alt="${App.escapeHtml(pet.name)}" />
        </div>
        <div class="swipe-card-body">
          <div class="pet-card-top">
            <h2 style="font-size:24px;font-weight:600;">${App.escapeHtml(pet.name)}</h2>
            <span style="font-size:12px;font-weight:500;">${App.escapeHtml(`${pet.gender} · ${pet.age_label}`)}</span>
          </div>
          <p style="font-size:14px;">${App.escapeHtml(`${pet.breed} · ${(pet.personality_json || []).slice(0, 3).join(', ')}`)}</p>
          <p style="font-size:12px;display:flex;align-items:center;gap:6px;">
            ${App.icon('map-pin')}<span>${App.escapeHtml(pet.location)}</span>
          </p>
          <p style="font-size:14px;padding-top:4px;">${App.escapeHtml(pet.description)}</p>
          <div class="swipe-card-footer">
            <span style="display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:500;">
              ${App.icon('shield')} Health Verified
            </span>
            <button type="button" class="btn-link" data-view-pet="${App.escapeHtml(pet.id)}" style="text-decoration:underline;">
              View Full Profile
            </button>
          </div>
        </div>
      </div>

      <div class="swipe-controls">
        <button type="button" class="circle-btn" id="swipe-pass-btn" data-swipe-action="pass" data-pet-id="${App.escapeHtml(pet.id)}" aria-label="Pass pet">
          ${App.icon('x-lg')}
        </button>
        <button type="button" class="circle-btn sm" id="swipe-undo-btn" ${swipeState.undoStack.length === 0 ? 'disabled' : ''} aria-label="Undo last swipe">
          ${App.icon('rotate')}
        </button>
        <button type="button" class="circle-btn like" id="swipe-like-btn" data-swipe-action="like" data-pet-id="${App.escapeHtml(pet.id)}" aria-label="Like and save pet">
          ${App.icon('heart-lg')}
        </button>
      </div>

      <p class="swipe-remaining">${deck.length} companion${deck.length === 1 ? '' : 's'} remaining</p>
    `;
  }

  async function handleSwipeAction(petId, action) {
    swipeState.swipedIds.push(petId);
    swipeState.undoStack.push(petId);
    renderSwipeStage();

    try {
      const res = await App.apiRequest('/swipes', {
        method: 'POST',
        body: JSON.stringify({ petId, action }),
      });
      if (action === 'like') {
        App.state.favouriteIds = res.petIds || App.state.favouriteIds;
        App.renderNavbar();
        renderSwipeStage();
        App.showToast('Saved match!');
      }
      await App.loadUserDashboardData();
      App.renderNavbar();
      renderSwipeStage();
    } catch (err) {
      App.showToast(err.message);
    }
  }

  document.addEventListener('click', (e) => {
    const spEl = e.target.closest('[data-swipe-species]');
    if (spEl) {
      swipeState.speciesPref = spEl.getAttribute('data-swipe-species');
      renderSwipeStage();
      return;
    }

    if (e.target.closest('#swipe-saved-top-btn') || e.target.closest('#swipe-open-saved-btn')) {
      App.openSavedModal();
      return;
    }

    const actEl = e.target.closest('[data-swipe-action]');
    if (actEl) {
      handleSwipeAction(actEl.getAttribute('data-pet-id'), actEl.getAttribute('data-swipe-action'));
      return;
    }

    if (e.target.closest('#swipe-undo-btn')) {
      const lastId = swipeState.undoStack.pop();
      if (lastId) {
        swipeState.swipedIds = swipeState.swipedIds.filter((id) => id !== lastId);
        renderSwipeStage();
      }
      return;
    }

    if (e.target.closest('#swipe-reset-btn')) {
      swipeState.swipedIds = [];
      swipeState.undoStack = [];
      renderSwipeStage();
    }
  });

  App.initPage('swipe', renderSwipeStage, renderSwipeStage);
})();
