/*
 * ============================================================================
 * FurEver — Veterinary Directory Page Script (public/vets.html)
 * ============================================================================
 * Filters Pune veterinary clinics by search keyword or 24/7 emergency flag.
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  const vetsFilter = {
    search: '',
    emergencyOnly: false,
  };

  function renderVetCard(clinic) {
    return `
      <article class="vet-card">
        <div class="stack-sm">
          <div class="vet-card-top">
            <div>
              <h2 style="font-size:18px;font-weight:600;">${App.escapeHtml(clinic.clinic_name)}</h2>
              <p style="font-size:14px;font-weight:500;">${App.escapeHtml(clinic.vet_name)}</p>
            </div>
            <span class="pill-badge" style="background-color:${clinic.emergency_24_7 ? '#D5C2FA' : '#EAE0FF'};">
              ${clinic.emergency_24_7 ? '24/7 Emergency' : 'Wellness Care'}
            </span>
          </div>

          <div style="font-size:14px;" class="stack-sm">
            <p style="display:flex;align-items:flex-start;gap:8px;">
              ${App.icon('map-pin')}<span>${App.escapeHtml(clinic.address)}</span>
            </p>
            <p style="display:flex;align-items:center;gap:8px;">
              ${App.icon('clock')}<span>${App.escapeHtml(clinic.hours)}</span>
            </p>
          </div>

          <p style="font-size:12px;">
            <strong>Services:</strong> ${App.escapeHtml((clinic.services_json || []).join(' · '))}
          </p>
        </div>

        <div class="vet-card-actions">
          <a href="tel:${App.escapeHtml(clinic.phone)}" class="btn btn-primary btn-xs">
            ${App.icon('phone')}<span>${App.escapeHtml(clinic.phone)}</span>
          </a>
          ${
            clinic.email
              ? `<a href="mailto:${App.escapeHtml(clinic.email)}" class="btn btn-soft btn-xs">${App.icon('mail')}<span>Email Clinic</span></a>`
              : ''
          }
        </div>
      </article>
    `;
  }

  function renderVetsList() {
    const area = document.getElementById('vets-results-area');
    if (!area) return;

    const query = vetsFilter.search.trim().toLowerCase();
    const filtered = (App.state.vets || []).filter((clinic) => {
      if (vetsFilter.emergencyOnly && !clinic.emergency_24_7) return false;
      if (query) {
        const text = `${clinic.clinic_name} ${clinic.vet_name} ${clinic.city} ${clinic.address} ${(clinic.services_json || []).join(' ')}`.toLowerCase();
        if (!text.includes(query)) return false;
      }
      return true;
    });

    area.innerHTML =
      filtered.length === 0
        ? '<div class="empty-card"><p style="font-size:14px;">No veterinary clinics matched your search.</p></div>'
        : `<div class="vets-grid">${filtered.map(renderVetCard).join('')}</div>`;
  }

  document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'vets-search-input') {
      vetsFilter.search = e.target.value;
      renderVetsList();
    }
  });

  document.addEventListener('change', (e) => {
    if (e.target && e.target.id === 'vets-emergency-check') {
      vetsFilter.emergencyOnly = e.target.checked;
      renderVetsList();
    }
  });

  App.initPage('vets', renderVetsList, renderVetsList);
})();
