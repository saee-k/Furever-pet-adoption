/*
 * ============================================================================
 * FurEver — Home Page Script (public/index.html)
 * ============================================================================
 * Renders:
 *   1. The Hero featured pet card (Bobi or first available pet)
 *   2. The available pets count
 *   3. The 6-card "Pets Waiting for a Home" grid
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  function renderHome() {
    const pets = App.state.pets || [];
    const availablePets = pets.filter((pet) => pet.status === 'AVAILABLE');
    const heroPet = pets.find((pet) => pet.id === 'pet-bobi') || availablePets[0] || pets[0];

    // 1. Update the available companion count in the hero eyebrow
    const availableEl = document.getElementById('home-available-count');
    if (availableEl) {
      availableEl.textContent = String(availablePets.length);
    }

    // 2. Render the featured Hero Pet card
    const heroCardWrap = document.getElementById('home-hero-card-wrap');
    if (heroCardWrap) {
      heroCardWrap.innerHTML = heroPet
        ? `
          <div class="hero-pet-card" data-view-pet="${App.escapeHtml(heroPet.id)}">
            <div class="hero-pet-img-wrap">
              <img src="${App.escapeHtml(heroPet.primary_image_url)}" alt="${App.escapeHtml(`${heroPet.name} — ${heroPet.breed}`)}" />
            </div>
            <div class="hero-pet-meta">
              <div>
                <h2 class="hero-pet-name">${App.escapeHtml(heroPet.name)}</h2>
                <p class="hero-pet-sub">${App.escapeHtml(`${heroPet.breed} · ${heroPet.age_label}`)}</p>
              </div>
              <span class="pill-badge">${heroPet.status === 'AVAILABLE' ? 'Available' : 'Under Review'}</span>
            </div>
          </div>
        `
        : '';
    }

    // 3. Render the 6 featured pet cards
    const featuredGrid = document.getElementById('home-featured-grid');
    if (featuredGrid) {
      featuredGrid.innerHTML = pets.slice(0, 6).map(App.renderPetCardHtml).join('');
    }
  }

  App.initPage('home', renderHome, renderHome);
})();
