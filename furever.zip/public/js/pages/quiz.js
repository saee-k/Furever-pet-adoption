/*
 * ============================================================================
 * FurEver — Match Finder Quiz Page Script (public/quiz.html)
 * ============================================================================
 * Walks the user through 6 lifestyle questions, sends answers to
 * POST /api/quiz/recommend, and renders ranked pet matches.
 * ============================================================================
 */

(() => {
  const App = window.FurEverApp;

  const QUIZ_QUESTIONS = [
    { key: 'preferredSpecies', question: 'Which kind of pet are you interested in adopting?', options: ['Any', 'Dog', 'Cat', 'Rabbit', 'Bird'] },
    { key: 'livingSpace', question: 'What best describes your home environment?', options: ['Apartment', 'House with Yard', 'Independent House', 'Spacious Villa'] },
    { key: 'dailyAvailability', question: 'How much time can you spend with your pet each day?', options: ['1-2 hours', '2-4 hours', '4+ hours', 'Work from home'] },
    { key: 'activityLevel', question: 'What activity level matches your daily lifestyle?', options: ['Low', 'Moderate', 'High'] },
    { key: 'petExperience', question: 'What is your previous experience caring for pets?', options: ['First-time', 'Some Experience', 'Experienced'] },
    { key: 'preferredAge', question: 'Do you prefer a particular age stage?', options: ['Any', 'Young', 'Adult', 'Senior'] },
  ];

  const quizState = {
    step: 0,
    answers: {
      preferredSpecies: 'Any',
      livingSpace: 'Apartment',
      dailyAvailability: '2-4 hours',
      activityLevel: 'Moderate',
      petExperience: 'First-time',
      preferredAge: 'Any',
    },
    results: null,
    loading: false,
  };

  function renderResults(container) {
    const cardsHtml = quizState.results
      .map(
        (item) => `
          <div>
            <div class="match-meta-row">
              <span class="pill-badge tabular-nums" style="font-weight:600;">${App.escapeHtml(item.matchScore)}% Match</span>
              <span style="font-size:12px;">${App.escapeHtml((item.matchReasons && item.matchReasons[0]) || 'Good lifestyle fit')}</span>
            </div>
            ${App.renderPetCardHtml(item.pet)}
          </div>
        `
      )
      .join('');

    container.className = 'container section-pad';
    container.innerHTML = `
      <div class="page-header">
        <div>
          <h1 class="page-title">Your Recommended Matches</h1>
          <p class="page-subtitle">Ranked by compatibility with your home, schedule, and experience.</p>
        </div>
        <button type="button" class="btn btn-white" id="quiz-retake-btn">Retake Quiz</button>
      </div>
      <div class="pet-grid">${cardsHtml}</div>
    `;
  }

  function renderQuestion(container) {
    const q = QUIZ_QUESTIONS[quizState.step];
    const progressPercent = Math.round(((quizState.step + 1) / QUIZ_QUESTIONS.length) * 100);
    const isLastStep = quizState.step === QUIZ_QUESTIONS.length - 1;

    const optionsHtml = q.options
      .map((opt) => {
        const selected = quizState.answers[q.key] === opt;
        return `
          <button type="button" class="quiz-option${selected ? ' selected' : ''}" data-quiz-key="${App.escapeHtml(q.key)}" data-quiz-val="${App.escapeHtml(opt)}">
            <span>${App.escapeHtml(opt)}</span>
            ${selected ? App.icon('check') : ''}
          </button>
        `;
      })
      .join('');

    container.className = 'container-xs section-pad';
    container.innerHTML = `
      <div style="margin-bottom:24px;">
        <p style="font-size:12px;font-weight:500;">Question ${quizState.step + 1} of ${QUIZ_QUESTIONS.length}</p>
        <h1 class="page-title" style="margin-top:4px;">Match Finder Quiz</h1>
        <div class="progress-track"><div class="progress-fill" style="width:${progressPercent}%;"></div></div>
      </div>

      <div class="quiz-card">
        <h2 style="font-size:20px;font-weight:500;">${App.escapeHtml(q.question)}</h2>
        <div class="quiz-options">${optionsHtml}</div>
        <div class="quiz-nav-row">
          <button type="button" class="btn btn-white" id="quiz-back-btn" ${quizState.step === 0 ? 'disabled' : ''}>
            ${App.icon('arrow-left')}<span>Back</span>
          </button>
          ${
            isLastStep
              ? `<button type="button" class="btn btn-primary" id="quiz-submit-btn" ${quizState.loading ? 'disabled' : ''}>${quizState.loading ? 'Finding Matches...' : 'See My Matches'}</button>`
              : `<button type="button" class="btn btn-primary" id="quiz-next-btn"><span>Next</span>${App.icon('arrow-right')}</button>`
          }
        </div>
      </div>
    `;
  }

  function renderQuiz() {
    const container = document.getElementById('quiz-container');
    if (!container) return;
    if (quizState.results) renderResults(container);
    else renderQuestion(container);
  }

  document.addEventListener('click', async (e) => {
    const optEl = e.target.closest('[data-quiz-key]');
    if (optEl) {
      quizState.answers[optEl.getAttribute('data-quiz-key')] = optEl.getAttribute('data-quiz-val');
      renderQuiz();
      return;
    }

    if (e.target.closest('#quiz-back-btn')) {
      quizState.step = Math.max(0, quizState.step - 1);
      renderQuiz();
      return;
    }

    if (e.target.closest('#quiz-next-btn')) {
      quizState.step = Math.min(QUIZ_QUESTIONS.length - 1, quizState.step + 1);
      renderQuiz();
      return;
    }

    if (e.target.closest('#quiz-submit-btn')) {
      quizState.loading = true;
      renderQuiz();
      try {
        const res = await App.apiRequest('/quiz/recommend', {
          method: 'POST',
          body: JSON.stringify(quizState.answers),
        });
        quizState.results = res.recommendations || [];
      } catch (err) {
        App.showToast(err.message);
      } finally {
        quizState.loading = false;
        renderQuiz();
      }
      return;
    }

    if (e.target.closest('#quiz-retake-btn')) {
      quizState.results = null;
      quizState.step = 0;
      renderQuiz();
    }
  });

  App.initPage('quiz', renderQuiz, () => {
    if (quizState.results) renderQuiz();
  });
})();
