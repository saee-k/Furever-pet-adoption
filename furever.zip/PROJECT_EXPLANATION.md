# FurEver — Student Project & Conceptual Explanation Guide

This guide explains how **FurEver** works in plain, easy-to-follow terms so you can understand, edit, and present every part of the project.

---

## 1. High-Level Architecture (How Everything Connects)

FurEver follows a clean **3-tier web architecture** with **zero frontend frameworks**:

```text
[ Pure HTML5 + CSS3 + Vanilla JS (Browser) ]
        │   fetch('/api/...') with JSON or FormData + optional x-user-id header
        ▼
[ Node.js + Express Server (server.ts) ]
        │   Serves static HTML/CSS/JS pages + REST API routes -> Controllers -> Model
        ▼
[ MySQL Database (mysql2) ]
        └── Normalized SQL Tables (or local JSON fallback if MySQL is offline)
```

1. **Frontend (`public/`)**: Pure **HTML5** pages (`index.html`, `browse.html`, `swipe.html`, `quiz.html`, `list-pet.html`, `vets.html`, `status.html`, `admin.html`), pure **CSS3** (`css/style.css`), and modular **Vanilla JavaScript** (`js/common.js` + `js/pages/*.js`).
2. **Backend (`server.ts` & `backend/`)**: **Node.js + Express** listens on port `3000`, serves the HTML/CSS/JS pages, resolves the active user from SQL (no JWT tokens), evaluates quiz/adoption logic, and saves uploaded pet photos (`multer`).
3. **Database (`database/` & `backend/models/`)**: **MySQL** via `mysql2/promise` (or `data/furever-db.json` fallback when MySQL is offline).

---

## 2. Easy-to-Find Page Map (One HTML + One JS File Per Page)

| Page | URL | HTML File | Page JavaScript File |
| --- | --- | --- | --- |
| **Home** | `/` or `/index.html` | `public/index.html` | `public/js/pages/home.js` |
| **Browse Pets** | `/browse` or `/browse.html` | `public/browse.html` | `public/js/pages/browse.js` |
| **Swipe Match** | `/swipe` or `/swipe.html` | `public/swipe.html` | `public/js/pages/swipe.js` |
| **Match Quiz** | `/quiz` or `/quiz.html` | `public/quiz.html` | `public/js/pages/quiz.js` |
| **List a Pet** | `/list-pet` or `/list-pet.html` | `public/list-pet.html` | `public/js/pages/list-pet.js` |
| **Veterinary Directory** | `/vets` or `/vets.html` | `public/vets.html` | `public/js/pages/vets.js` |
| **Status & Activity** | `/status` or `/status.html` | `public/status.html` | `public/js/pages/status.js` |
| **Admin Dashboard** | `/admin` or `/admin.html` | `public/admin.html` | `public/js/pages/admin.js` |

Every page also loads:
- `public/css/style.css` — All layout, colors, cards, forms, and modal styles.
- `public/js/common.js` — Shared `FurEverApp` helper (Navbar, Footer, Pet Cards, `apiRequest()`, Toast banner, and Modals).

---

## 3. Step-by-Step Request Flow (Frontend ↔ Backend ↔ Database)

### Example A: Opening Browse Pets (`/browse.html`)
1. The browser loads `public/browse.html`, `public/css/style.css`, `public/js/common.js`, and `public/js/pages/browse.js`.
2. `browse.js` calls `App.initPage('browse', renderBrowseResults)`.
3. `common.js` calls `fetch('/api/pets')` and `fetch('/api/auth/me')`.
4. Express routes `GET /api/pets` (`backend/routes/apiRouter.ts`) → `PetController.listPets` → `FurEverModel.listPets()`.
5. Express returns `{ pets: [...] }` in JSON.
6. `browse.js` filters those pets in the browser as you type or pick species/age/Pune neighbourhood filters.

### Example B: Submitting an Adoption Application
1. User clicks **View Details** → **Apply to Adopt** inside the Pet Details modal (`common.js`).
2. Submitting the form sends `POST /api/applications` with an optional `x-user-id` header (no JWT needed).
3. `requireAuth` (`backend/middleware/auth.ts`) reads the active user from the SQL `users` table (or defaults to the guest adopter session if not logged in).
4. `ApplicationController.submitApplication` checks the 20-word minimum and home suitability (`APPLICABLE` or `NOT_APPLICABLE`).
5. `FurEverModel.createApplication()` inserts the application and notification into SQL, and the UI refreshes immediately.

---

## 4. Sample SQL Queries Used in the Project

```sql
-- 1. Fetch all available pets ordered by featured status
SELECT * FROM pets
WHERE status = 'AVAILABLE'
ORDER BY is_featured DESC, created_at DESC;

-- 2. Join pet details with the shelter/lister user
SELECT p.*, u.full_name AS lister_name, u.email AS lister_email
FROM pets p
JOIN users u ON p.lister_id = u.id
WHERE p.id = ?;

-- 3. Insert or update a Swipe Match decision
INSERT INTO swipe_history (id, user_id, pet_id, action)
VALUES (?, ?, ?, ?)
ON DUPLICATE KEY UPDATE action = VALUES(action);

-- 4. Update adoption application status
UPDATE adoption_applications
SET status = ?, reviewer_notes = ?
WHERE id = ?;
```

---

## 5. Common Conceptual Questions & Simple Answers

**Q1: How do Create Account and Login work without JWT tokens?**  
During registration (`AuthController.register`), `bcryptjs` hashes the password and inserts a row into the SQL `users` table. On login (`AuthController.login`), Express verifies the password hash and returns the `user` object. The browser stores `user.id` in `localStorage` and sends it in the `x-user-id` header. Users can also browse, swipe, apply, or list pets without logging in first.

**Q2: How does the Match Quiz algorithm work?**  
In `InteractionController.submitQuiz`, each available pet starts at a score of `50`, and points are adjusted by comparing your 6 answers (`preferredSpecies`, `livingSpace`, `dailyAvailability`, `activityLevel`, `petExperience`, `preferredAge`) against the pet's attributes.

**Q3: How do image uploads work when listing a pet?**  
`public/js/pages/list-pet.js` sends the `<form>` as `FormData` (`multipart/form-data`). On the server, **Multer** (`backend/routes/apiRouter.ts`) validates that the file is an image under 5 MB, saves it in `public/uploads/`, and stores `/uploads/<filename>` in the database.

**Q4: Why is there a local JSON store fallback inside `backend/config/db.ts`?**  
If MySQL is not running locally, `initDatabase()` automatically switches to `localStore.ts` (`data/furever-db.json`) so every page works immediately, while still using real `mysql2` SQL queries whenever MySQL credentials are active in `.env`.
